import { TestBed } from '@angular/core/testing';

import { SustaibilityServiceService } from './sustaibility-service.service';

describe('SustaibilityServiceService', () => {
  let service: SustaibilityServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SustaibilityServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
