import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
// import { GoalData } from '../shared/components/sustaibility-goals/sustainability.model'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class SustaibilityServiceService {
  httpClient: any;
  constructor(private http: HttpClient) {}
  goals: any;

  getGoals(data:any){
    return this.http.post('http://localhost:4000/sustainability-goals',data);
  }
  showGoals( ) {
    return this.http.get('http://localhost:4000/sustainability-goals' );
  }

 

  removeGoal(id: Number) {
    return this.httpClient.delete('');
  }

  updateGoal(goal: any, updatedGoal: any) {
    const index = this.goals.indexOf(goal);
    if (index > -1) {
      this.goals[index] = updatedGoal;
    }
  }
}
