import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/auth/auth.service';
import { CarbonService } from '../carbon-track/carbon.service';
import { SustaibilityServiceService } from '../../sustaibility-service.service';
 interface UserProfile {
  email: string;
  carbonFootprint: number;
  sustainabilityGoals: { goal: string; progress: number }[];
}
 interface CarbonData {
   transportation: number;
   energyConsumption: number;
   wasteDisposal: number;
 }

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css'],
})
export class UserProfileComponent implements OnInit {
  userProfile: UserProfile | null = null;
  CarbonData: any;
  sustainability: any;
  
  error: string | null = null;
  profile: any;
  users!: any[];
  myForm!: FormGroup;
  isEdit: boolean = false;
  carbons: any;
  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private carbonservice: CarbonService,
    private Sustainabilityservice: SustaibilityServiceService,
  ) {}

  ngOnInit() {
    let user = sessionStorage.getItem('useremail');
    console.log(user);
    this.authService.getUser({ email: user }).subscribe((res) => {
      console.log(res);
      this.profile = res;
    });
    this.myForm = this.fb.group({
      email: [
        '',
        [
          Validators.required,
          Validators.pattern(
            /^[_A-Za-z0-9-\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$/
          ),
        ],
      ],
    });

    this.carbonservice.showCarbon().subscribe((data: any) => {
      console.log(data);
      this.CarbonData = data;
    });

    this.Sustainabilityservice.showGoals().subscribe((data: any) => {
      console.log(data);
      this.sustainability = data;

    });
  }

  edit() {
    this.isEdit = true;
    this.myForm.controls['email'].setValue(this.profile.email);
  }

  submit() {
    this.authService
      .updateUser({
        newemail: this.myForm.controls['email'].value,
        email: this.profile.email,
      })
      .subscribe((res) => {
        console.log(res);
        alert('profile updated successfully');
        sessionStorage.setItem(
          'useremail',
          this.myForm.controls['email'].value
        );
        this.profile.email = this.myForm.controls['email'].value;
      });
  }
}
  
 


 