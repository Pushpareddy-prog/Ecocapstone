import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { SustaibilityServiceService } from '../../sustaibility-service.service';
 @Component({
  selector: 'app-sustaibility-goals',
  templateUrl: './sustaibility-goals.component.html',
  styleUrls: ['./sustaibility-goals.component.css'],
})
export class SustaibilityGoalsComponent {
 
  constructor(
    private http: HttpClient,
    private sustainabilityService: SustaibilityServiceService
  ) {}
 
   GoalsData = [
    {
      id: '1',
      title: 'Enahce Eco Friendly',
      description:
        'Being eco-friendly also saves me a lot of money each year.It has also launched sustainable cotton jeans and eco-friendly glitter. There are eco-friendly cleaning products and personal care items.',
      progress: 4.8,
      imageUrl: '../../../../assets/9.png',
      // goals:'goals'
    },
    {
      id: '2',
      title: 'Sustainable Agriculture',
      description:
        'producing food and livestock over the long term with minimal negative effects on the environment. Its goal is to provide food for growing human populations .',
      progress: 4.8,
      imageUrl: '../../../../assets/4.png',
    },
    {
      id: '3',
      title: ' Carbon Footprint',
      description:
        'It can be defined as an environmental indicator that represents the number of greenhouse gasses (GHGs), in the form of CO2 equivalents',
      progress: 4.8,
      imageUrl: '../../../../assets/8.png',
    },
    {
      id: '4',
      title: ' Renewable Energy',
      description:
        'Reducing short-lived climate pollutants can have immediate economic benefits from job creation and increased household income',
      progress: 4.8,
      imageUrl: '../../../../assets/7.png',
    },
    {
      id: '5',
      title: ' Water Conservation',
      description:
        'Water supply systems must also meet requirements for public, commercial, and industrial activities. In all cases, the water must fulfill both quality and quantity requirements.',
      progress: 4.8,
      imageUrl: '../../../../assets/1.png.png',
    },
    {
      id: '6',
      title: ' Recycling',
      description:
        'Recycling reduces the need to extract resources such as timber, water, and minerals for new products ',
      progress: 4.9,
      imageUrl: '../../../../assets/3.png',
    },
  ];
 
    addGoal(data:any) {
      this.sustainabilityService.getGoals(data).subscribe(
        (response) => {
          console.log('Goal posted successfully:', response);
        }

      );
    }
  
  // this.sustainabilityService.addGoal(item, newGoal);
  removeGoal(event:any,id:Number) {
    if (confirm('Are you sure')) {
    event.target.innerText="Deleting"
  }
}
  updateGoal(goal: any, updatedGoal: any) {
    this.sustainabilityService.updateGoal(goal, updatedGoal);
    window.alert('Goal updated successfully!');
  }
}
