import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SustaibilityGoalsComponent } from './sustaibility-goals.component';

describe('SustaibilityGoalsComponent', () => {
  let component: SustaibilityGoalsComponent;
  let fixture: ComponentFixture<SustaibilityGoalsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SustaibilityGoalsComponent]
    });
    fixture = TestBed.createComponent(SustaibilityGoalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
