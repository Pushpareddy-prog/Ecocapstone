import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarbonTrackComponent } from './carbon-track.component';

describe('CarbonTrackComponent', () => {
  let component: CarbonTrackComponent;
  let fixture: ComponentFixture<CarbonTrackComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CarbonTrackComponent]
    });
    fixture = TestBed.createComponent(CarbonTrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
