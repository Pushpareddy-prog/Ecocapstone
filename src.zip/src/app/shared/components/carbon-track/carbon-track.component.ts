import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CarbonService } from './carbon.service';
  

@Component({
  selector: 'app-carbon-track',
  templateUrl: './carbon-track.component.html',
  styleUrls: ['./carbon-track.component.css'],
})
export class CarbonTrackComponent {
  message: string = 'Total Emission :';
  myForm1!: FormGroup;
  sum: number = 0;
  // form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private router: Router, private carbonservice: CarbonService
  ) { }

  ngOnInit() {
    this.myForm1 = this.fb.group({
      id:[null,Validators.required],
      transportation: [null, Validators.required],
      energyConsumption: [null, Validators.required],
      wasteDisposal: [null, Validators.required],
    });
  }

  onSubmit(): void {
    // this.calculateSum();
    this.carbonservice.postCarbon(this.myForm1.value).subscribe(
      (response) => {
        console.log('Stored successfully', response);
        alert('Carbon footprint tracked successfully');
        // this.router.navigate(['/login']);
      },
      (error) => {
        console.error('Error occured while tracking carbon footprint. Please try again.', error);
      }
    );
  }

  calculateSum() {
    //  const numbers = (this.myForm1.get('numbers') as FormArray).value.map(
    //     (value:any) => parseFloat(value.replace(/[^0-9.]/g, '')) || 0 // Handle non-numeric values as 0
    //   );
    //   this.sum = numbers.reduce((acc, num) => acc + num, 0);

 
  }

}
 
 





