import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CarbonService {
  constructor(private http:HttpClient) {}

  postCarbon(data: any) {
    return this.http.post(
      'http://localhost:4000/carbon-footprint/users/:userId',
      data
    );
  }
  showCarbon( ) {
    return this.http.get('http://localhost:4000/showcarbon-foorprint' );
  }
}
