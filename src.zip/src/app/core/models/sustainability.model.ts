interface GoalsData {
  id: String;
  title: String;
  description: String;
  progress: number;
}
