import { TestBed } from '@angular/core/testing';

import { SustainabilityServiceService } from './sustainability-service.service';

describe('SustainabilityServiceService', () => {
  let service: SustainabilityServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SustainabilityServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
