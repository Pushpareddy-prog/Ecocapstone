import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';


interface UserProfile {
  email: string;
  carbonFootprint: number;
  sustainabilityGoals: { goal: string; progress: number }[];
}
@Injectable({
  providedIn: 'root',
})
export class UserService {
 
  private baseUrl = 'http://localhost:3000/profile'; // Replace with your Node.js server URL

  constructor(private http: HttpClient) {}

  getUserProfile(): Observable<UserProfile> {
    return this.http
      .get<UserProfile>(this.baseUrl)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: any): Observable<any> {
    console.error('An error occurred:', error);
    return throwError('Something went wrong retrieving user profile');
  }
}

