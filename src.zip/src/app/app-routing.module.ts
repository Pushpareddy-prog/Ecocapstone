import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { UserProfileComponent } from './shared/components/user-profile/user-profile.component';
import { CarbonTrackComponent } from './shared/components/carbon-track/carbon-track.component';
import { SustaibilityGoalsComponent } from './shared/components/sustaibility-goals/sustaibility-goals.component';
import { LogoutComponent } from './auth/logout/logout.component';
import { ResetpasswordComponent } from './auth/resetpassword/resetpassword.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'UserProfile', component: UserProfileComponent },
 { path: 'carbontrack', component: CarbonTrackComponent },
  { path: 'sustainabilitygoals', component: SustaibilityGoalsComponent },
  { path: 'logout', component: LogoutComponent },
  {path:'resetpassword',component:ResetpasswordComponent},
 
  { path: '**', redirectTo: '/register', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
