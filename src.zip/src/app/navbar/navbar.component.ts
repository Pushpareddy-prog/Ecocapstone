import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent {
  constructor(private router: Router) {}
  view() {
    this.router.navigate(['/UserProfile']);
  }
  view1() {
    this.router.navigate(['/register']);
  }
  view2() {
    this.router.navigate(['/login']);
  }
  view3() {
     this.router.navigate(['/logout']);
  }
}
