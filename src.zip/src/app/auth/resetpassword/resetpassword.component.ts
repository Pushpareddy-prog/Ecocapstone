import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css'],
})
export class ResetpasswordComponent {
  // password: string;
  // confirmPassword: string;
  // token: string;
  // errorMessage: string = null;

  // constructor(
  //   private route: ActivatedRoute,
  //   private router: Router,
  //   private authService: AuthService
  // ) {} // Inject services

  // ngOnInit() {
  //   this.token = this.route.snapshot.paramMap.get('token'); // Retrieve token from URL
  // }

  // onSubmit() {
  //   this.errorMessage = null;
  //   this.authService
  //     .resetPassword(this.token, this.password, this.confirmPassword) // Call your auth service method
  //     .subscribe(
  //       () => {
  //         // Handle successful password reset (e.g., show success message and redirect)
  //         alert('Password reset successfully!');
  //         this.router.navigate(['/login']); // Redirect to login page
  //       },
  //       (error) => {
  //         this.errorMessage = error.message; // Handle error message from auth service
  //       }
  //     );
  // }
}
