import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  myForm!: FormGroup;
  myname: any;
  form!: FormGroup;
  password: any;
  profile: any;
  data: any;
  isEdit: boolean= false;
   successMessage!: string;
  errorMessage!: string;
  users: any;
  constructor(
    private authService: AuthService,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.myForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
    });
  }
  openModal() {
    const modal = document.getElementById('forgotPasswordModal');
    // modal.style.display = 'block';
  }

  loginUser() {
    const email = this.myForm.controls['email'].value;
    const pwd = this.myForm.controls['password'].value;
    this.authService.login(email, pwd).subscribe({
      next: (authenticated: any) => {
        if (authenticated) {
          this.successMessage = 'login successfull!!';
          sessionStorage.setItem('useremail', email);
          this.router.navigate(['/carbontrack']);
        } else {
          this.errorMessage = 'Invalid Credentials. Try again!!.';
        }
      },
    });
  }


  edit() {
    this.isEdit = true;
    this.myForm.controls['password'].setValue(this.profile.password);
  }

  submit() {
    this.authService
      .updatepassword({
        newpassword: this.myForm.controls['password'].value,
        password: this.profile.password,
      })
      .subscribe((res) => {
        console.log(res);
        alert('profile updated successfully');
        sessionStorage.setItem(
          'password',
          this.myForm.controls['password'].value
        );
        this.profile.password = this.myForm.controls['password'].value;
      });
  }


}
