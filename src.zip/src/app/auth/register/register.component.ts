import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { AuthService } from '../auth.service';
// import { subscribe } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  myForm!: FormGroup;
 
  submitted = false;
  // error: string;
  constructor(private fb: FormBuilder, private authService:AuthService,private http: HttpClient,private router:Router) { }
  ngOnInit() {
    this.myForm = this.fb.group(
      {
        name: [
          '',
          [
            Validators.required,
            Validators.minLength(4),
            Validators.maxLength(10),
          ],
        ],
        email: [
          '',
          [
            Validators.required,
            Validators.pattern(
              /^[_A-Za-z0-9-\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$/
            ),
          ],
        ],
        phoneno: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
        dob: ['', [Validators.required, this.customValidator]],
        password: [
          '',
          [
            Validators.pattern(
              /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
            ),
          ],
        ],
        confirmPassword: ['', [Validators.required]],
        acceptTerms: [false, Validators.requiredTrue],
      },
      {
        validators: this.passwordMatchValidator,
      }
    );
  }

  
    register(): void {
    this.authService.register(this.myForm.value).subscribe(
        response => {
        console.log('User registered successfully', response);
        this.router.navigate(['/login'])
        },
        error => {
           console.error('Error registering user', error);
        }
      );
    }
  
  
    
  
  //  if (this.myForm.valid) {
  //     console.log(this.myForm.value);
  //     this.router.navigate(['/login']);
  //     alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.myForm.value, null, 4));
  //   }

  

  customValidator(control: AbstractControl): ValidationErrors | null {
    if (control.value) {
      const today = new Date();
      const dob = new Date(control.value);
      const age = today.getFullYear() - dob.getFullYear();

      if (age < 18) {
        return { underage: true };
      }
    }
    return null;
  }

  passwordMatchValidator(formData: FormGroup) {

    const myForm = formData.value;
    const password = myForm.password;
    const confirmPassword = formData.controls['confirmPassword'].value;
    if (password !== confirmPassword) {
      console.log( formData.controls['confirmPassword'].value);
      formData.controls['confirmPassword'].setErrors({ value12: "password mismatch" });
            console.log(formData.controls['confirmPassword'])
      // return { passwordMismatch: 'passwordMismatch' };
    }
    //return null;
  }
}


