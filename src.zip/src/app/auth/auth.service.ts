import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseURL = 'http://localhost:4000';
  constructor(private http: HttpClient) {}

  login(email: string, password: string) {
    return this.http.post('http://localhost:4000/auth/login', {
      email,
      password,
    });
  }

  register(data: any) {
    return this.http.post('http://localhost:4000/auth/register', data);
  }
  getUser(user: any) {
    return this.http.post('http://localhost:4000/auth/profile', user);
  }
  updateUser(data: any) {
    return this.http.put('http://localhost:4000/auth/profile/update', data);
  }
  updatepassword(data: any) {
    return this.http.put('http://localhost:4000/auth/password/update', data);
  }
}
